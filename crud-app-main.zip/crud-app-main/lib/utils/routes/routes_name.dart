class RoutesName {
  static const String splash = 'splash_screen';
  static const String login = 'login_screen';
  static const String signup = 'signup_screen';
  static const String addData = 'add_screen';
  static const String dataScreen = 'data_screen';
  static const String forgotPassword = 'forgot_screen';
}
